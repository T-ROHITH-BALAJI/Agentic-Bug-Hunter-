import pandas as pd

def main():
    df = pd.read_csv("samples.csv")
    print("First 10 Code IDs in input dataset:")
    print(df["ID"].head(10).tolist())

if __name__ == "__main__":
    main()
