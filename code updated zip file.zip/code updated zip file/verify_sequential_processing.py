import pandas as pd

def main():
    samples = pd.read_csv("samples.csv")
    output = pd.read_csv("output.csv")

    same_order = samples["ID"].tolist() == output["Code ID"].tolist()

    print("All Code IDs processed sequentially:", same_order)

if __name__ == "__main__":
    main()
