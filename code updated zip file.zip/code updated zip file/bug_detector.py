from sympy import re
import re

def detect_bug_line(code: str, mcp_results: list):
    """
    Detect buggy line using MCP-derived bug descriptions.

    Args:
        code (str): incorrect C/C++ code
        mcp_results (list): output from MCPClient.search_bug_manual

    Returns:
        (line_number, line_text)
    """

    lines = code.splitlines()

    # Step 1: extract meaningful keywords from MCP text
    keywords = set()
    for res in mcp_results:
        for word in re.findall(r"[A-Za-z_]{4,}", res["text"]):
            keywords.add(word.lower())

    # Step 2: scan code line-by-line for violations
    for idx, line in enumerate(lines):
        for key in keywords:
            if key in line.lower():
                return idx + 1, line.strip()

    # Fallback (if nothing matched)
    return None, None
