import pandas as pd

def main():
    samples = pd.read_csv("samples.csv")
    output = pd.read_csv("output.csv")

    merged = samples.merge(output, left_on="ID", right_on="Code ID")

    print("Code IDs shown during validation (first 3 rows):")
    print(merged["ID"].head(3).tolist())

if __name__ == "__main__":
    main()
