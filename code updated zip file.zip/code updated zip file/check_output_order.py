import pandas as pd

def main():
    df = pd.read_csv("output.csv")
    print("First 10 Code IDs in output dataset:")
    print(df["Code ID"].head(10).tolist())

if __name__ == "__main__":
    main()
