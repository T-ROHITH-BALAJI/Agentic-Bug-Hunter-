from pathlib import Path
import pandas as pd
from orchestrator import process_row

BASE_DIR = Path(__file__).resolve().parent.parent
df = pd.read_csv(BASE_DIR / "samples.csv")

results = []

for _, row in df.iterrows():
    bug_line, explanation = process_row(row)

    results.append({
        "Code ID": row["ID"],
        "Detected Bug Line": bug_line,
        "Generated Explanation": explanation
    })

out_df = pd.DataFrame(results)
out_df.to_csv(BASE_DIR / "output.csv", index=False)

print("output.csv generated successfully")
